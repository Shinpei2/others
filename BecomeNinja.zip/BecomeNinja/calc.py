practices = []
practices.append({"menu": "a","distance":1.00, "time":280, "pace":280})
practices.append({"menu": "a","distance":1.00, "time":300, "pace":280})
practices.append({"menu": "a","distance":1.00, "time":490, "pace":280})

# TODO: Insert Data into Practice-Table and Prac_detail-Table
# total_distance = 0.0
# total_time = 0
# total_pace = 0
# for item in practices:
#     total_distance += item["distance"]
#     total_time += item["time"]
# print(total_distance, total_time)
# total_pace = (int)(total_time/total_distance)
# print(total_pace)

def calc_pace(dist, time):
    pace_m = (int)((time / dist) / 60)
    pace_s = (int)((time / dist) % 60)
    return round(pace_m + pace_s / 100, 2)

def calc_to_sec(min, sec):
    return min * 60 + sec

if __name__ == "__main__":
    pace = calc_pace(15, 4500)
    print(pace)
    print(calc_to_sec(20, 40))