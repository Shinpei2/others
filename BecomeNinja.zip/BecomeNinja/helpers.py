import os
import requests
import urllib.parse
from flask import redirect, render_template, request, session
from functools import wraps
from datetime import date,timedelta
from dateutil.relativedelta import relativedelta


def apology(message, code=400):
    """Render message as an apology to user."""
    def escape(s):
        """
        Escape special characters.

        https://github.com/jacebrowning/memegen#special-characters
        """
        for old, new in [("-", "--"), (" ", "-"), ("_", "__"), ("?", "~q"),
                         ("%", "~p"), ("#", "~h"), ("/", "~s"), ("\"", "''")]:
            s = s.replace(old, new)
        return s
    return render_template("apology.html", top=code, bottom=escape(message)), code

def login_required(f):
    """
    Decorate routes to require login.

    http://flask.pocoo.org/docs/1.0/patterns/viewdecorators/
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if session.get("user_id") is None:
            return redirect("/login")
        return f(*args, **kwargs)
    return decorated_function

def get_first_date(dt):
    return dt.replace(day=1)

def get_last_date(dt):
    return (dt + relativedelta(months=1)).replace(day=1) - timedelta(days=1)

def add_month(dt):
    return dt + relativedelta(months=1)

def calc_pace(dist, time):
    if time == 0:
        return 0.0
    pace_m = (int)((time / dist) / 60)
    pace_s = (int)((time / dist) % 60)
    return round(pace_m + pace_s / 100, 2)

def calc_min_sec(time):
    min = (int)(time / 60)
    sec = (int)(time % 60)
    return round(min + sec / 100, 2)

def calc_to_sec(min, sec):
    return min * 60 + sec